﻿# Welcome to Blazor Markdown Viewer

This is an example of rendering Markdown in a Blazor application.

## Features

- Render **Markdown** files
- Easily customizable
- Lightweight and fast

Enjoy using Blazor and Markdown together!
